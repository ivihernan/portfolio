#ifndef CANDIDATURA_H_INCLUDED
#define CANDIDATURA_H_INCLUDED


#define DIM_SIGLAS 20
#define DIM_NOMBRE_CANDIDATURA 100

int cargaListaCandidaturasAD(char siglas[][DIM_SIGLAS], char nombre[][DIM_NOMBRE_CANDIDATURA]);


#endif
