#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <stdbool.h>
#include "candidatoAD.h"
#include "../IU/interfazGrafica.h"
#include "../IU/CandidatoIU.h"
#include <locale.h>

#define DIM_SIGLA 12
#define DIM_EDAD 2
#define DIM_NOMBRE_CANDIDATO 40

int cargaListaCandidatosAD(char candidatura[][DIM_SIGLA], int edad[], char nombre[][DIM_NOMBRE_CANDIDATO])
{
    int contador = 0;
    char letras[50];
    /*Definimos las variables que van a leer el archivo txt*/

    FILE *archivo;
    /*Abrimos el archivo con la siguiente ruta*/
    archivo=fopen("BaseDatos/candidatos.txt","rt");

    /*Si no se pudo abrir el archivo devolvemos -1*/
    if(archivo == NULL){
        gotoxy(22,37);
        printf("No se pudo abrir el archivo, ruta no encontrada");
        return -1;
    }
    fgets(letras, 50, archivo);
        while (fscanf(archivo, "%s %d", candidatura[contador], &edad[contador]) == 2)
        {
            fgets(nombre[contador], 255, archivo);
            contador++;
        }
    fclose(archivo);
    return contador;
}

int cargaListaCandidatosAD2(char candidatura[][DIM_SIGLA], int edad[], char nombre[][DIM_NOMBRE_CANDIDATO], char ficheroElegido[])
{
    int contador = 0;
    char letras[50];
    char cadena[80]="BaseDatos/";
    /*Definimos las variables que van a leer el archivo txt*/

    FILE *archivo;
    ficheroElegido = strcat(cadena, ficheroElegido);
    /*Abrimos el archivo con la siguiente ruta*/
    archivo=fopen(ficheroElegido,"rt");

    /*Si no se pudo abrir el archivo devolvemos -1*/
    if(archivo == NULL){
        gotoxy(22,37);
        printf("No se pudo abrir el archivo, ruta no encontrada");
        return -1;
    }
    fgets(letras, 50, archivo);
        while (fscanf(archivo, "%s %d", candidatura[contador], &edad[contador]) == 2)
        {
            fgets(nombre[contador], 255, archivo);
            contador++;
        }
    fclose(archivo);
    return contador;
}

bool altaCandidatoAD(char candidato[], char edad[], char candidatura[])
{
    FILE *ptr;
    /*volvemos a abrir el archivo txt*/
    ptr = fopen("BaseDatos/candidatos.txt", "at");
    if (ptr == NULL)
    {
        /*Error al abrir el archivo*/
        return false;
    }
    /*Si se pudo abrir el archivo entonces retornamos true y pintamos en el txt la informacion proporcionada*/
    else
    {
        fprintf(ptr, "%s\t %d\t %s\t\n", candidatura, edad, candidato);
        fclose(ptr);
        return true;
    }
}


void cargaCandidatosxCandidatura(char siglas[][DIM_SIGLA])
{
     /*Declaramos la variables*/
    char candidatura[100][DIM_SIGLA];
    int edad[100];
    char nombre[100][DIM_NOMBRE_CANDIDATO];
    /*llamamamos a la funcion para saber cuantos candidatos tenemos*/
    int cantidadCandidatos = cargaListaCandidatosAD(candidatura, edad, nombre);

    if (cantidadCandidatos == -1) {
        gotoxy(22, 37);
        printf("Error al abrir el archivo");
        gestionMenuCandidatos();
    } else if (cantidadCandidatos == 0) {
        gotoxy(22, 37);
        printf("No hay candidatos registrados");
    } else {
        int i, b;
        int ejeY = 7;
        for (b = 0; b < 4; b++)
        {
            for (i = 0; i < cantidadCandidatos; i++)
            {
                if (strcmp(siglas[b], candidatura[i]) == 0)
                {
                    gotoxy(4, ejeY);
                    printf("%s %d %s", candidatura[i], edad[i], nombre[i]);
                    ejeY++;
                }
            }

        }
        gotoxy(22,37);
        system("pause");
        borraVentana(1,6,50,25);
    }
}
