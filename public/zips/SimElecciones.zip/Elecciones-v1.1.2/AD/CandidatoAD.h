#ifndef CANDIDATOAD_H_INCLUDED
#define CANDIDATOAD_H_INCLUDED
#include <stdbool.h>

#define DIM_SIGLA 12
#define DIM_EDAD 2
#define DIM_NOMBRE_CANDIDATO 40


int cargaListaCandidatosAD(char candidatura[][DIM_SIGLA], int edad[], char nombre[][DIM_NOMBRE_CANDIDATO]);
int cargaListaCandidatosAD2(char candidatura[][DIM_SIGLA], int edad[], char nombre[][DIM_NOMBRE_CANDIDATO], char ficheroElegido[]);
bool altaCandidatoAD(char candidato[], char edad[], char candidatura[]);
void cargaCandidatosxCandidatura(char siglas[][DIM_SIGLA]);

#endif

