#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <locale.h>
#include "candidatura.h"
#include "../IU/interfazGrafica.h"

#define DIM_SIGLAS 20
#define DIM_NOMBRE_CANDIDATURA 100

int cargaListaCandidaturasAD(char siglas[][DIM_SIGLAS], char nombre[][DIM_NOMBRE_CANDIDATURA])
{
    int contador = 0;

    FILE *archivo;
    /* Abre el archivo de datos "candidaturas.txt" */
    archivo=fopen("BaseDatos/candidaturas.txt","rt");

    if (archivo == NULL) {
        perror("Error al abrir el archivo");
        return -1;
    }
    while (fscanf(archivo, "%s", siglas[contador]) == 1)
        {
            siglas[contador][strcspn(siglas[contador], "\n")] = '\0';
            nombre[contador][strcspn(nombre[contador], "\n")] = '\0';
            fgets(nombre[contador], 200, archivo);
            contador++;
        }

    /*Utiliza un bucle while para leer los datos de cada siglas
    while (contador < 100 && fgets(siglas[contador], DIM_SIGLAS, archivo) && fgets(nombre[contador], DIM_NOMBRE_CANDIDATURA, archivo)) {
        /*Elimina el salto de l�nea al final de cada l�nea
        siglas[contador][strcspn(siglas[contador], "\n")] = '\0';
        nombre[contador][strcspn(nombre[contador], "\n")] = '\0';
        contador++;
    }*/

   /* Cierra el archivo de texto*/
    fclose(archivo);

    /*Retorna el n�mero de candidaturas cargadas*/
    return contador;
}
