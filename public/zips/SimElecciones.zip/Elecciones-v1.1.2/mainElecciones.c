#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
/*importamos todos los archivos .h para que funcionen las funciones definidas*/
#include "IU/interfazGrafica.h"
#include "IU/interfazUsuario.h"
#include "IU/CandidatoIU.h"
#include "AD/CandidatoAD.h"
#include "IU/candidaturaIU.h"

int main()
{
    setlocale(LC_CTYPE, "Spanish");
    system("title Proyecto integrador"); /* le metemos titulo al proyecto*/
    inicInterfazUsuario();/* se llama a la funcion interfaz usuario*/
    gestionMenuPrincipal();
    /* llamamos a la gestionMenuCandidatos para mostar el menu*/
    return 0;
}
