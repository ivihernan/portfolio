#include <stdio.h>
#include <locale.h>
#include <ctype.h>
#include <stdbool.h>
#include "CandidatoIU.h"
#include "interfazGrafica.h"
#include "../AD/CandidatoAD.h"
#include "../SYS/candidatoSYS.h"
#include "candidaturaIU.h"

#define DIM_SIGLA 12
#define DIM_EDAD 2
#define DIM_NOMBRE_CANDIDATO 40


void altaCandidatoIU(){
    /*definimos variables*/
    char candidatura[20];
    char nombre[20];
    char edad[20];
    char msg[100]= "";
    int i;

    /* pedimos al usuario la distinta informacion para el candidato*/
    gotoxy(21,33);
    printf("Introduce candidatura del candidato (siglas):");
    gets(candidatura);
    /*borramos las ventanas para que salga las nuevas preguntas*/
    borraVentana(21,33,80,2);
    gotoxy(2,7);
    printf("Candidatura:");
    puts(candidatura);

    gotoxy(21,33);
    printf("Introduce nombre del candidato:");
    gets(nombre);
    borraVentana(21,33,80,2);
    gotoxy(2,8);
    printf("Nombre:");
    puts(nombre);

    gotoxy(21,33);
    printf("Introduce la edad: ");
    gets(edad);
    borraVentana(21,33,80,2);
    gotoxy(2,9);
    printf("Edad:");
    puts(edad);

   /*Verificamos si todos los caracteres de la cadena son d�gitos
   para ello crearemos un bucle for para comprobar que todo esta en orden*/
    bool esNumero = true;
    for (i = 0; i < strlen(edad); i++) { /*el strlen es para ver determinar los caracteres que hay en la cadena edad*/
        if (!isdigit(edad[i])) {
            esNumero = false;
            break;
        }
    }

    /*si todo fue bien llamaremos a la funcion altaCandidatoSYS
    //en caso contrario diremos que el numero proporcionado por el usuario no es numero
    //y devolveremos un mensaje de error*/
    if (esNumero) {
    altaCandidatoSYS(nombre, edad, candidatura, msg);
    } else {
        gotoxy(21, 33);
        printf("No es un numero entero, introduzca un numero");
    }


     gotoxy(21,37);
    system("pause");
    borraVentana(1,6,50,25);
}


void listadoCandidatos(void)
{
    /*Declaramos la variables*/
    char candidatura[100][DIM_SIGLA];
    int edad[100];
    char nombre[100][DIM_NOMBRE_CANDIDATO];
    /*llamamamos a la funcion para saber cuantos candidatos tenemos*/
    int cantidadCandidatos = cargaListaCandidatosAD(candidatura, edad, nombre);

    if( cantidadCandidatos == -1)
    {
        gotoxy(22,37);
        printf("Error al abrir el archivo");
        gestionMenuCandidatos();
    }
    /*dependiendo del valor de cantidadandidatos hacemos una cosa u otra*/
    switch(cantidadCandidatos)
    {
    case 0:
        gotoxy(22,37);
        printf("No hay candidatos registrados");
        break;
    default:
        muestraListaCandidatos(cantidadCandidatos, candidatura, edad, nombre);
    }
    gotoxy(21,37);
    system("pause");
    borraVentana(1,6,50,25);
    borraVentana(56,6,50,25);
}

void muestraListaCandidatos(int cantidadCandidatos, char candidatura[][DIM_SIGLA], int edad[], char nombre[][DIM_NOMBRE_CANDIDATO])
{
    int ejeY = 9;
    int i;
    setlocale(LC_CTYPE, "Spanish");
    /*Creamos la interfaz para mostrar los candidatos con sus valores leidos del archivo*/
    gotoxy(58, 7);
    printf("%-5s %-5s %-5s", "Candidatura","Edad","Candidato");
    for(i = 1; i < cantidadCandidatos; i++){
        if (ejeY <= 28){
        gotoxy(58, ejeY);
        muestraCandidato(candidatura[i], edad[i], nombre[i]);
        }
        ejeY++;
    }
     borraVentana(21,33,85,2);
}


void muestraCandidato(char candidatura[], int edad, char nombre[])
{
    setlocale(LC_CTYPE, "Spanish");
    /*mostramos por pantalla los datos proporcionados por el usuario*/
    printf("%s %d %s",candidatura, edad, nombre);
}


/*creacion del menu*/
int menuCandidatos()
{
    int opcion;
    /*mostramos por pantalla las distintas opcion que tiene el usuario*/
    gotoxy(2,9);
    printf("1. Leer datos de candidatos");
    gotoxy(2,10);
    printf("2. Tramitar de alta un candidato");
    gotoxy(2, 11);
    printf("3. Listado de candidatos de una candidatura");
    gotoxy(2,12);
    printf("4. Candidatos con edad mayor y menor");
    gotoxy(2,13);
    printf("0. Fin de la gestion");
   /*le pedimos que nos de una*/
    gotoxy(21,33);
    printf("Seleccione una opcion: ");
    scanf("%d", &opcion);
    fflush(stdin);
    borraVentana(2,9,40,20);
    /* y por ultimo retornamos el valor dado*/
    return opcion;

}

void gestionMenuCandidatos()
{
    int opcion_menu;

    do{
        opcion_menu = menuCandidatos();

    setlocale(LC_CTYPE, "Spanish");
    /*almacenamos la opcion retornada de menuCandidatos en una variable
    creamos un switch para identificar las distintas opciones
    si ninguna coincide, creamos el default es decir que si no existe ninguna siempre se mostrara por
    pantalla esa opcion*/
    switch(opcion_menu)
        {
        case 1:
            listadoCandidatos();
            break;
        case 2:
            altaCandidatoIU();
            break;
        case 3:
            generaListadoCandidatos();
            break;
        case 4:
            candidatosEdadMayorMenor();
            break;
        }
    }while(opcion_menu != 0);
            borraVentana(21,33,80,2);
            borraVentana(21,37,80,2);
            borraVentana(1,6, 50, 25);
            borraVentana(56, 6, 50, 25);
}



void muestraCandidatosUnaCandidatura(char siglasSeleccion[DIM_SIGLA], int cantidadCandidatos, char candidatura[100][DIM_SIGLA], int edad[100] ,char nombre[100][DIM_NOMBRE_CANDIDATO])
{
    int i;
    int ejeY;

    ejeY = 9;

  if (cantidadCandidatos == -1) {
        gotoxy(22, 37);
        printf("Error al abrir el archivo");
    } else {
        switch (cantidadCandidatos) {
            case 0:
                gotoxy(22, 37);
                printf("No hay candidatos registrados");
                break;
            default:
                gotoxy(4,7);
                printf("Candidatos que tienen la candidatura %s", siglasSeleccion);
                for (i = 0; i < cantidadCandidatos; i++) {
                    if (strcmp(siglasSeleccion, candidatura[i]) == 0) {
                        gotoxy(4, ejeY);
                        printf("%s %d %s", candidatura[i], edad[i], nombre[i]);
                        ejeY++;
                    }
                }
                break;
        }
    }
}

void candidatosEdadMayorMenor()
{
   /*Declaramos la variables*/
    char candidatura[100][DIM_SIGLA];
    int edad[100];
    char nombre[100][DIM_NOMBRE_CANDIDATO];
    char ficheroElegido[80];
    int devolucionExisteFichero;
    int cantidadCandidatos;
    /*llamamamos a la funcion para saber cuantos candidatos tenemos*/
    borraVentana(1,6, 50,25);
    do{
        gotoxy(4,7);
        printf("1. candidatos.txt");
        gotoxy(4,8);
        printf("1. candidatos2.txt");
        gotoxy(4,9);
        printf("1. candidatos3.txt");
        gotoxy(21,33);
        printf("Introduzca uno de los ficheros que tenemos:");
        scanf("%s", ficheroElegido);
        devolucionExisteFichero = existeFichero(ficheroElegido);
        gotoxy(22,37);
        printf("Este archivo no existe, prueba con otro");
        borraVentana(21,33, 85,2);
    }while(devolucionExisteFichero == -1);
    cantidadCandidatos = cargaListaCandidatosAD2(candidatura, edad, nombre, ficheroElegido);
    muestraListaCandidatos(cantidadCandidatos, candidatura, edad, nombre);
    borraVentana(1,6, 50,25);
    borraVentana(21,33, 85,2);
    borraVentana(21,37, 85, 2);

    gotoxy(22,37);
    system("pause");
}

int existeFichero(char ficheroElegido[])
{
    FILE *archivo;
    char cadena[80]="BaseDatos/";

    ficheroElegido = strcat(cadena, ficheroElegido);

    archivo = fopen(ficheroElegido,"rt");
    if(archivo == NULL ){
        return -1;
    }
   /* gotoxy(4,7);
    printf("%s", ficheroElegido);
    gotoxy(22,37);
    system("pause");*/
    fclose(archivo);
    return 1;
}
