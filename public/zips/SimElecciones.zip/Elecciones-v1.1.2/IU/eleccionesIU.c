#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include "eleccionesIU.h"
#include "interfazGrafica.h"

#define NUM_CANDIDATURAS 20
#define DIM_SIGLAS 20
#define DIM_NOMBRE_CANDIDATURA 100
#define NUM_CANDIDATURA 10


void muestraResultadoElecciones(int numCandidaturas, char siglas[][DIM_SIGLAS], char nombre[][DIM_NOMBRE_CANDIDATURA], int votos[], int escanos[])
{
    int i, j=0;
    setlocale(LC_ALL, "Spanish");

    gotoxy(58, 7);
    printf("Siglas \t Candidaturas\tVotos\t Escanos");
    for(i = 0; i<numCandidaturas; i++)
    {
        if(j>=19)
        {
            gotoxy(24,25);
            system("pause");
            j=0;
            continue;
        }
        gotoxy(58, 9+j);
        printf("%s \t %s\t", siglas[i], nombre[i]);
        gotoxy(92, 9+j);
        printf("%d \t%d", votos[i], escanos[i]);
        j++;
        if(i == numCandidaturas)
        {
            gotoxy(24,25);
            system("pause");
            continue;
        }
    }
    gotoxy(22,37);
    system("pause");

}
/* Funci�n para mostrar los votos de cada candidatura
*/
void muestraListaVotos(int numCandidaturas, int escano, int indice, int votos[])
 {
    int i;
    printf("%d\t", escano);
    for (i = 0; i < numCandidaturas; i++) {
            if( i== indice ){
                setColorTexto(6,3);
            }
        printf("%d\t", votos[i]);
        setColorTexto(5,15);
    }
}

