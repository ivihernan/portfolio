#ifndef CANDIDATOIU_H_INCLUDED
#define CANDIDATOIU_H_INCLUDED


#define DIM_SIGLA 12
#define DIM_EDAD 2
#define DIM_NOMBRE_CANDIDATO 40

void altaCandidatoIU(void);
void listadoCandidatos(void);
void muestraListaCandidatos(int cantidadCandiatos, char candidatura[][DIM_SIGLA], int edad[],char nombre[][DIM_NOMBRE_CANDIDATO]);
void muestraCandidato(char candidatura[], int edad, char nombre[]);
int menuCandidatos(void);
void gestionMenuCandidatos(void);

void muestraCandidatosUnaCandidatura(char siglasSeleccion[DIM_SIGLA], int cantidadCandidatos, char candidatura[100][DIM_SIGLA], int edad[100] ,char nombre[100][DIM_NOMBRE_CANDIDATO]);

void candidatosEdadMayorMenor();
int existeFichero(char ficheroElegido[]);

#endif
