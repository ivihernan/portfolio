#ifndef CANDIDATURAIU_H_INCLUDED
#define CANDIDATURAIU_H_INCLUDED

#define DIM_SIGLAS 20
#define DIM_NOMBRE_CANDIDATURA 100
#define DIM_SIGLA 12

void gestionMenuCandidaturas();
void listadoCandidaturas();
int menuCandidaturas();
void muestraListaCandidaturas(int cantidadCandidaturas, char siglas[][DIM_SIGLAS], char nombre[][DIM_NOMBRE_CANDIDATURA]);
void muestraCandidatura(char siglas[], char candidatura[]);
void listadoCandidatosxCandidatura();
void generaListadoCandidatos();
int seleccionaCandidatura(int cantidadCandidaturas, char siglas[][DIM_SIGLAS]);


#endif
