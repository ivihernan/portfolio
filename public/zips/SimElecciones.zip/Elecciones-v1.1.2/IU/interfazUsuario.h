#ifndef INTERFAZUSUARIO_H_INCLUDED
#define INTERFAZUSUARIO_H_INCLUDED


void inicInterfazUsuario(void);
void gestionMenuPrincipal();
int menuPrincipal();

#endif
