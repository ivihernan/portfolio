#include <stdio.h>
#include <stdlib.h>
#include "interfazGrafica.h"
#include "candidaturaIU.h"
#include "CandidatoIU.h"
#include "interfazUsuario.h"


void inicInterfazUsuario()
{
    system("color F0"); /*le a�adimos color a la terminal*/
    system("mode con cols=110 lines=45"); /* y tambien numero de columnas y filas */
    /*agregamos los distintos rectangulos para la interfaz*/
    rectangulo(0,0,105,2,5,15);
    gotoxy(40,1);
    printf("SIMULADOR DE ELECCIONES");

    rectangulo(0,5,50,25,5,15);
    rectangulo(55,5,50,25,5,15);

    rectangulo(20,32,85,2,5,15);
    rectangulo(0,32,15,2,5,15);
    gotoxy(2,33);
    printf("ENTRADA DATOS:");

    rectangulo(20,36,85,2,5,15);
    rectangulo(0,36,15,2,5,15);
    gotoxy(2,37);
    printf("MENSAJES:");

}

void gestionMenuPrincipal()
{
    int opcion_escogida;

    do{
    opcion_escogida = menuPrincipal();
        switch(opcion_escogida)
        {
        case 1:
            borraVentana(21,33,80,2);
            borraVentana(21,37,80,2);
            gestionMenuCandidatos();
            break;
        case 2:
            borraVentana(21,33,80,2);
            borraVentana(21,37,80,2);
            gestionMenuCandidaturas();
            break;
        default:
            gotoxy(22,37);
            printf("El menu que elegiste no existe");
        }
    }while(opcion_escogida != 0);
}

int menuPrincipal()
{
    int opcion;

    gotoxy(2,9);
    printf("1. Gestion de candidatos");

    gotoxy(2,10);
    printf("2. Gestion de Candidaturas");

    gotoxy(2,11);
    printf("0. Fin del programa");

    gotoxy(21,33);
    printf("Seleccione una opcion: ");
    scanf("%d", &opcion);
    fflush(stdin);
    borraVentana(2,9,40,20);

    return opcion;
}
