#include <windows.h>

enum graficos1
{
    ESIZQ=218, ESDER=191, LHOR=196, EIIZQ= 192,
    EIDER= 217, TDER = 195, TIZQ = 180
};


#define ANC_TXT 68 /* ancho de la línea en el archivo de texto */
#define FONDO_BLANCO (BACKGROUND_BLUE  | BACKGROUND_GREEN | BACKGROUND_RED | BACKGROUND_INTENSITY)
#define TEXTO_ROJO (FOREGROUND_RED | FOREGROUND_INTENSITY)
#define TEXTO_AZUL ( FOREGROUND_BLUE| FOREGROUND_INTENSITY)
#define TEXTO_VERDE (FOREGROUND_GREEN | FOREGROUND_INTENSITY)
#define TEXTO_BLANCO (FOREGROUND_RED | FOREGROUND_BLUE | FOREGROUND_GREEN | FOREGROUND_INTENSITY)
#define FONDO_AZUL (BACKGROUND_BLUE  | BACKGROUND_INTENSITY)

#define FILAS 38
#define ANC_TOTAL  125
#define FILAS_TOTAL 35

#define ANC_SEL 60
#define ANC_CESTA 60
#define ANCHO_ES 106


void rectangulo(int x, int y, int ancho, int alto, char pincel, char lienzo);
void borraVentana(int x, int y, int cols, int filas);
void setColorTexto(int pincel, int lienzo);
void gotoxy(int x, int y);
void modoTexto();
void modoGrafico();


