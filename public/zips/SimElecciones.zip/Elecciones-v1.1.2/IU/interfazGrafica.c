/*! \file interfazGrafica.c
 *
 * \brief Contiene la definici�n de las funciones incluidas
          en la biblioteca libinterfazGrafica.a.
 */

/* Para crear la biblioteca:
  $ gcc -static -c interfazGrafica.c -o interfazGrafica.o
  $ ar -rcs libinterfazGrafica.a interfazGrafica.o
  */
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <conio.h>
#include <ctype.h>
#include "interfazGrafica.h"

/*! Dibuja un rect�ngulo en la consola.
 * \param [in] x Columna de la esquina superior izquierda del rect�ngulo.
 * \param [in] y Fila de la esquina superior izquierda del rect�ngulo.
 * \param [in] ancho Anchura del rect�ngulo (en columnas).
 * \param [in] alto Altura del rect�ngulo (en filas).
 * \param [char] cadena de dos caracteres: lienzo y pincel

 */
void rectangulo(int x, int y, int ancho, int alto, char pincel, char lienzo)
{
    int i, j;

    setColorTexto(pincel, lienzo);
    setlocale(LC_CTYPE, "C"); /* Activo caracteres est�ndar */
    /* Dibuja lado superior del rect�ngulo */
    system("color ");
    gotoxy(x, y);
    printf("%c", ESIZQ);
    for(i=x+1; i<x+ancho+1; i++)
        printf("%c", 196);
    printf("%c", ESDER);
    /* Dibuja lados verticales del rect�ngulo. */
    for(i=y+1; i<y+alto+1; i++)
    {
        for(j=x; j<=x+ancho+1; j++)
        {
            gotoxy(j ,i);
            if(j==x)
            {
                printf("%c", 179);
            }
            else if(j>x && j< x+ancho+1)
            {
                printf(" ");
            }
            else if(j==x+ancho+1)
            {
                printf("%c", 179);
            }
        }
    }
    /* Dibuja lado inferior del rect�ngulo */
    gotoxy(x, y+alto+1);
    printf("%c", EIIZQ);
    for(i=x+1; i<x+ancho+1; i++)
        printf("%c", 196);
    printf("%c", EIDER);

    return;
}

/*! Borra una ventana (escribiendo el caracter en blanco ' ')
    que comienza en la columna \c x, fila \c y, y que tiene una
    anchura de \c ancho columnas, y una altura de \c alto filas.

 * \param [in] x Columna de la esquina superior izquierda de la ventana.
 * \param [in] y Fila de la esquina superior izquierda de la ventana.
 * \param [in] ancho Anchura de la ventana (en columnas).
 * \param [in] alto Altura de la ventana (en filas).
 */
void borraVentana(int x, int y, int ancho, int alto)
{
    int i;
    char formato[10];
    sprintf(formato, "%%%ds", ancho);
    for(i=0; i<alto; i++)
    {
        gotoxy(x, y + i);
        printf(formato, " ");
    }
    return;
}


/*! Determina los colores de tinta y fondo para el texto
 * \param [in] colores Combinaci�n de colores seleccionada.
 */
void setColorTexto(int pincel, int lienzo)
{
   int colores;
    HANDLE hConsole=GetStdHandle(STD_OUTPUT_HANDLE);
    colores = pincel + (lienzo<<4);
    SetConsoleTextAttribute(hConsole, colores);
}

/*! Coloca el cursor en la columna x, fila y de la consola.

    \param [in] x N�mero de columna
    \param [in] y N�mero de fila
*/
void gotoxy(int x, int y)
{
    COORD coord;
    coord.X = x;
    coord.Y = y;
    if(SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord)==0)
    {
        printf("error en gotoxy(%d,%d).\n", x, y);
        system("pause");
    }
    return;
}


/* Establecer el idioma a espa�ol*/
void modoTexto()
{
    setlocale(LC_CTYPE, "spanish"); /* Cambiar locale - Suficiente para m�quinas Linux*/
    SetConsoleCP(1252); /* Cambiar STDIN -  Para m�quinas Windows*/
    SetConsoleOutputCP(1252); /* Cambiar STDOUT - Para m�quinas Windows*/
}

/* Establecer el idioma al predeterminado */
void modoGrafico()
{
    setlocale(LC_CTYPE, "C"); /* Cambiar locale - Suficiente para m�quinas Linux*/
    SetConsoleCP(850); /* Cambiar STDIN -  Para m�quinas Windows*/
    SetConsoleOutputCP(850); /* Cambiar STDOUT - Para m�quinas Windows*/
}


