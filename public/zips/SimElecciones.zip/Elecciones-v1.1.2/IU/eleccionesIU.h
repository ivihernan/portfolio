#ifndef ELECCIONESIU_H_INCLUDED
#define ELECCIONESIU_H_INCLUDED

#define NUM_CANDIDATURAS 20
#define DIM_SIGLAS 20
#define DIM_NOMBRE_CANDIDATURA 100
#define NUM_CANDIDATURA 10


void muestraResultadoElecciones(int numCandidaturas, char siglas[][DIM_SIGLAS], char nombre[][DIM_NOMBRE_CANDIDATURA], int votos[], int escanos[]);
void muestraListaVotos(int numCandidaturas, int escano, int indice, int votos[]);


#endif
