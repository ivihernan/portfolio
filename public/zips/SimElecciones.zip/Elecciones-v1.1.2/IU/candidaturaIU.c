#include <stdio.h>
#include <locale.h>
#include <stdlib.h>
#include <time.h>
#include "interfazGrafica.h"
#include "candidaturaIU.h"
#include "../AD/candidatura.h"
#include "../SYS/eleccionesSYS.h"
#include "../AD/CandidatoAD.h"
#include "CandidatoIU.h"

#define DIM_SIGLAS 20
#define DIM_NOMBRE_CANDIDATURA 100


#define DIM_SIGLA 12
#define DIM_EDAD 2
#define DIM_NOMBRE_CANDIDATO 40

void gestionMenuCandidaturas()
{
    int opcion;
    /*creamos el menu de candidaturas borrando las ventanas que teniamos de antes*/
    do{
    opcion = menuCandidaturas();
        switch(opcion)
        {
        case 1:
            listadoCandidaturas();
            break;
        case 2:
            simElecciones();
            break;
        case 3:

            listadoCandidatosxCandidatura();
            break;
        default:
            gotoxy(22,37);
            printf("No es una opcion valida esa, lo siento");
        }
    }while(opcion != 0);
            borraVentana(21,33,80,2);
            borraVentana(21,37,80,2);
            borraVentana(1,6, 50, 25);
            borraVentana(56, 6, 50, 25);
}

int menuCandidaturas()
{
    int opcion;

    gotoxy(2,9);
    printf("1. Listado de candidaturas.");

    gotoxy(2, 10);
    printf("2. Simulaciones de elecciones");

    gotoxy(2,11);
    printf("3. Listado de candidatos por candidatura");

    gotoxy(2,12);
    printf("0. Fin de la gestion");

    gotoxy(21,33);
    printf("Seleccione una opcion: ");
    scanf("%d", &opcion);
    fflush(stdin);
    borraVentana(2,9,40,20);

    return opcion;
}

void listadoCandidaturas()
{
    char siglas[100][DIM_SIGLAS]; /*Arreglo para almacenar las siglas de las candidaturas*/
    char nombre[100][DIM_NOMBRE_CANDIDATURA]; /* Arreglo para almacenar los nombres de las candidaturas*/
    int cantidadCandidaturas;

    cantidadCandidaturas = cargaListaCandidaturasAD(siglas, nombre);

    /*Seguimos mirando dependiendo del valor dado*/
    if(cantidadCandidaturas == -1){
        gotoxy(22, 37);
        printf("Se ha producido un error en la carga de la lista de candidaturas");
    }
    switch (cantidadCandidaturas) {
        case 0:
            gotoxy(22, 37);
            printf("No hay candidaturas registradas en el archivo candidaturas.txt");
            break;
        default:
            muestraListaCandidaturas(cantidadCandidaturas, siglas, nombre);
    }
    gotoxy(21,37);
    system("pause");
    borraVentana(1,6,50,25);
}
/*Lo mostramos por pantalla */
void muestraListaCandidaturas(int cantidadCandidaturas,  char siglas[][DIM_SIGLAS], char nombre[][DIM_NOMBRE_CANDIDATURA])
{
    int ejeY = 7;
    int i;
    for (i = 0; i < cantidadCandidaturas; i++) {
        if (ejeY<27)
        {

            gotoxy(2, ejeY);
            muestraCandidatura(siglas[i], nombre[i]);
            ejeY++;
        }
    }
}

void muestraCandidatura(char siglas[], char nombre[])
{
    setlocale(LC_CTYPE, "Spanish");
    printf("%s %s", siglas, nombre);
}


void listadoCandidatosxCandidatura()
{
    char siglas[100][DIM_SIGLAS]; /*Arreglo para almacenar las siglas de las candidaturas*/
    char nombre[100][DIM_NOMBRE_CANDIDATURA]; /* Arreglo para almacenar los nombres de las candidaturas*/
    int cantidadCandidaturas;
    int i;

    cantidadCandidaturas = cargaListaCandidaturasAD(siglas, nombre);

    if(cantidadCandidaturas == -1){
        gotoxy(22, 37);
        printf("Se ha producido un error en la carga de la lista de candidaturas");
    }
    switch (cantidadCandidaturas) {
        case 0:
            gotoxy(22, 37);
            printf("No hay candidaturas registradas en el archivo candidaturas.txt");
            break;
        default:
            muestraListaCandidaturas(cantidadCandidaturas, siglas, nombre);
    }
    gotoxy(22,37);
    system("pause");
    borraVentana(1,6,50,25);

    for(i = 0; i< cantidadCandidaturas; i++)
    {
        cargaCandidatosxCandidatura(siglas[i]);
    }
}

void generaListadoCandidatos()
{
    char siglas[100][DIM_SIGLAS]; /*Arreglo para almacenar las siglas de las candidaturas*/
    char nombre[100][DIM_NOMBRE_CANDIDATURA]; /* Arreglo para almacenar los nombres de las candidaturas*/
    int cantidadCandidaturas;
    int seleccionCandidatura;
    borraVentana(1,6,50,25);
    cantidadCandidaturas = cargaListaCandidaturasAD(siglas, nombre);

    if(cantidadCandidaturas == -1){
        gotoxy(22, 37);
        printf("Se ha producido un error en la carga de la lista de candidaturas");
    }
    switch (cantidadCandidaturas) {
        case 0:
            gotoxy(22, 37);
            printf("No hay candidaturas registradas en el archivo candidaturas.txt");
            break;
        default:
            muestraListaCandidaturas(cantidadCandidaturas, siglas, nombre);
    }
    seleccionCandidatura = seleccionaCandidatura(cantidadCandidaturas, siglas);
    if(seleccionCandidatura == -1){
        system("exit");
    }else{
        char candidatura[100][DIM_SIGLA];
        int edad[100];
        char nombre[100][DIM_NOMBRE_CANDIDATO];
        /*llamamamos a la funcion para saber cuantos candidatos tenemos*/
        int cantidadCandidatos = cargaListaCandidatosAD(candidatura, edad, nombre);
        borraVentana(1,6, 50,25);
        borraVentana(21,37,85, 2);

        muestraCandidatosUnaCandidatura(siglas[seleccionCandidatura],cantidadCandidatos, candidatura, edad, nombre);
        gotoxy(22,37);
        system("pause");
        borraVentana(1,6,50,25);
        borraVentana(21,33,85, 2);
    }
}

int seleccionaCandidatura(int cantidadCandidaturas, char siglas[][DIM_SIGLAS])
{
    char siglasSeleccion[DIM_SIGLAS];
    int i ,seleccion;
    borraVentana(21,33,85, 2);
    gotoxy(22,33);
    printf("Introduzca una de las siglas: ");
    scanf("%s", siglasSeleccion);
    for(i = 0; i < cantidadCandidaturas; i++)
    {
        if(strcmp(siglasSeleccion, siglas[i]) == 0)
        {
            seleccion = i;
            break;
        }
    }
    if( seleccion == -1){
        gotoxy(22,33);
        printf("Las siglas no existen");
    }
    return seleccion;
}
