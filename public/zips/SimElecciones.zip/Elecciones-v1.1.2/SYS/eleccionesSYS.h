#ifndef ELECCIONESSYS_H_INCLUDED
#define ELECCIONESSYS_H_INCLUDED

#define NUM_CANDIDATURAS 20
#define DIM_SIGLAS 20
#define DIM_NOMBRE_CANDIDATURA 100
#define NUM_CANDIDATURA 10

void simElecciones();
int genVotaciones(int numCandidaturas, int votos[]);
void escrutinio(int numCandidaturas, int votos[], char siglas[][DIM_SIGLAS], int escanos[]);
int maximoVotos(int numCandidaturas, int votos[]);

#endif
