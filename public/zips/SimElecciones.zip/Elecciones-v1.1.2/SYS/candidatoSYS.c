#include <stdio.h>
#include <stdbool.h>
#include <locale.h>
#include "candidatoSYS.h"
#include "../IU/interfazGrafica.h"
#include "../IU/CandidatoIU.h"
#include "../AD/CandidatoAD.h"

void altaCandidatoSYS(char candidato[], char edad[], char candidatura[], char msg[])
{
    bool error = altaCandidatoAD(candidato, edad, candidatura);
    /*almacenamos el valor retornado de esta funcion en una variable de tipo bool*/
    /*miramos si nos da error y si es asi mostramos por pantalla un error*/
     if (error == false) {
        sprintf(msg, "No se pudo abrir el archivo, lo siento");
        gotoxy(21, 33);
        printf("%s", msg);
    } else
    {
        /*si el valor retornado es true mostramos por pantalla que todo funciono correctamente*/
        sprintf(msg, "Candidato %s agregado con exito!!!", candidato);
        gotoxy(21, 33);
        printf("%s", msg);
    }
}
