#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <time.h>
#include "eleccionesSYS.h"
#include "../AD/candidatura.h"
#include "../IU/eleccionesIU.h"
#include "../IU/interfazGrafica.h"

#define NUM_CANDIDATURAS 20
#define DIM_SIGLAS 20
#define DIM_NOMBRE_CANDIDATURA 100
#define NUM_CANDIDATURA 10

void simElecciones()
{
    char siglas[100][DIM_SIGLAS];
    char nombre[100][DIM_NOMBRE_CANDIDATURA];
    int votos[NUM_CANDIDATURAS];
    int escanos[NUM_CANDIDATURAS] = {0,0,0,0};

    /* Paso 1: Cargar lista de candidaturas*/
    int numCandidaturas;
    borraVentana(21, 33, 85, 2);
    borraVentana(57,7, 48, 24);

    numCandidaturas = cargaListaCandidaturasAD(siglas, nombre);

    /* Paso 2: Generar votaciones*/
    genVotaciones(numCandidaturas, votos);

    /* Paso 3: Mostrar resultados de votaciones (antes del escrutinio)*/
    if(numCandidaturas == -1){
        gotoxy(22, 37);
        printf("Se ha producido un error en la carga de la lista de candidaturas");
    }
    switch (numCandidaturas) {
        case 0:
            gotoxy(22, 37);
            printf("No hay candidaturas registradas en el archivo candidaturas.txt");
            break;
        default:
            muestraResultadoElecciones(numCandidaturas, siglas, nombre, votos, escanos);
    }
    gotoxy(21,37);
    system("pause");

    /* Paso 4: Realizar el escrutinio*/
    escrutinio(numCandidaturas, votos, siglas, escanos);
    gotoxy(21,37);
    system("pause");
    borraVentana(56, 6, 50 ,25);

    /* Paso 5: Mostrar resultados de votaciones (despu�s del escrutinio)*/
    muestraResultadoElecciones(numCandidaturas, siglas, nombre, votos, escanos);
    borraVentana(56, 6, 50 ,25);
    borraVentana(1,6, 50,25);
}

int genVotaciones(int numCandidaturas, int votos[])
{
    int i;
    int totalVotos;
    srand(time(NULL));
    totalVotos = 0;
    for (i = 0; i < numCandidaturas; i++) {
        votos[i] = rand() % 10000 +100; /*Generamos votos entre 0 y 9999*/
        totalVotos += votos[i];
    }

    return totalVotos;
}

void escrutinio(int numCandidaturas, int votos[], char siglas[][DIM_SIGLAS], int escanos[])
{
    int votos_aux[100];
    int i, k, f, indice;

    borraVentana(21, 33, 87, 2);

    gotoxy(8, 7);
    printf("Escanos FJP FPuJ FPoJ UPJ");

    for (k = 0; k < numCandidaturas; k++) {
        votos_aux[k] = votos[k];
    }
    for (i= 0; i < NUM_CANDIDATURAS; i++) {
        /* Encontrar el �ndice de la candidatura m�s votada*/
        indice = maximoVotos(numCandidaturas, votos_aux);
        gotoxy(8, 9+i);
        muestraListaVotos(numCandidaturas, i, indice, votos_aux);
        /*Incrementar los esca�os de la candidatura correspondiente*/
        escanos[indice]++;

        /* Actualizar los votos de la candidatura*/
        votos_aux[indice] = votos[indice] / (escanos[indice] + 1);
    }
    gotoxy(11,20);
    for(f = 0; f <= numCandidaturas; f++){
        printf("\t %d", escanos[f]);
    }
}

int maximoVotos(int numCandidaturas, int votos[])
{
    int i, indice = 0;
    int valor = votos[0];
    for(i = 0; i < numCandidaturas; i++)
        {
        if(valor < votos[i])
        {
            valor = votos[i];
            indice = i;
        }
    }
    return indice;
}


