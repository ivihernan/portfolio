#ifndef CANDIDATOSYS_H_INCLUDED
#define CANDIDATOSYS_H_INCLUDED

void altaCandidatoSYS(char candidato[], char edad[], char candidatura[], char msg[]);

#endif
